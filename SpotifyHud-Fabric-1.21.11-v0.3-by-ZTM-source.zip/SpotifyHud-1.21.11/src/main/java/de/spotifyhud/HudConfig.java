package de.spotifyhud;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;

final class HudConfig {
    static final HudConfig INSTANCE = load();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    boolean enabled = true;
    boolean gradient = true;
    boolean animatedGradient = false;
    boolean showCover = true;
    boolean showLyrics = true;
    int opacity = 78;
    String position = "top-right";
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("spotifyhud.json"); }
    static HudConfig load() {
        try { if (Files.exists(file())) return GSON.fromJson(Files.readString(file()), HudConfig.class); }
        catch (Exception ignored) {}
        return new HudConfig();
    }
    void save() {
        try { Files.createDirectories(file().getParent()); Files.writeString(file(), GSON.toJson(this)); }
        catch (Exception e) { e.printStackTrace(); }
    }
}
