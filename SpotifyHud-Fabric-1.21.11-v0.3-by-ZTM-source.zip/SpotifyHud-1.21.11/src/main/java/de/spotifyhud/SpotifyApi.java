package de.spotifyhud;

import com.google.gson.JsonParser;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.concurrent.*;

final class SpotifyApi {
    static volatile String title="Spotify nicht verbunden", artist="Token in Umgebungsvariable setzen";
    static volatile int colorA=0x4422AA, colorB=0xCC33AA;
    private static final HttpClient HTTP=HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final ScheduledExecutorService EXEC=Executors.newSingleThreadScheduledExecutor(r->{var t=new Thread(r,"Spotify-HUD");t.setDaemon(true);return t;});
    static void start(){ EXEC.scheduleAtFixedRate(SpotifyApi::poll,0,5,TimeUnit.SECONDS); }
    private static String token(){return System.getenv("SPOTIFY_ACCESS_TOKEN");}
    private static void poll(){
        String t=token(); if(t==null||t.isBlank()){title="Spotify nicht verbunden";artist="SPOTIFY_ACCESS_TOKEN fehlt";return;}
        try{
            var req=HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/currently-playing")).header("Authorization","Bearer "+t).timeout(Duration.ofSeconds(8)).GET().build();
            var res=HTTP.send(req,HttpResponse.BodyHandlers.ofString());
            if(res.statusCode()==204){title="Nichts wird abgespielt";artist="";return;}
            if(res.statusCode()==401){title="Spotify-Token abgelaufen";artist="Token erneuern";return;}
            if(res.statusCode()!=200)return;
            var root=JsonParser.parseString(res.body()).getAsJsonObject();
            if(!root.has("item")||root.get("item").isJsonNull()){title="Nichts wird abgespielt";artist="";return;}
            var item=root.getAsJsonObject("item"); title=item.get("name").getAsString();
            StringBuilder a=new StringBuilder(); for(var v:item.getAsJsonArray("artists")){if(a.length()>0)a.append(", ");a.append(v.getAsJsonObject().get("name").getAsString());}
            artist=a.toString();
            // Album image URL is available in item.album.images; image download/rendering is a follow-up feature.
            if(HudConfig.INSTANCE.animatedGradient){int tick=(int)(System.currentTimeMillis()/80); colorA=0x5522AA ^ ((tick&31)<<16); colorB=0xCC33AA ^ ((tick&31)<<8);}
        }catch(Exception ignored){}
    }
    static void command(String endpoint, String extra){
        String t=token(); if(t==null||t.isBlank())return;
        try{
            var b=HttpRequest.newBuilder(URI.create("https://api.spotify.com/v1/me/player/"+endpoint)).header("Authorization","Bearer "+t).timeout(Duration.ofSeconds(8));
            if(extra==null)b.POST(HttpRequest.BodyPublishers.noBody()); else b.PUT(HttpRequest.BodyPublishers.ofString(extra)).header("Content-Type","application/json");
            HTTP.sendAsync(b.build(),HttpResponse.BodyHandlers.discarding());
        }catch(Exception ignored){}
    }
    static void pause(){command("pause",null);} static void next(){command("next",null);} static void previous(){command("previous",null);}
    static void volume(int value){command("volume?volume_percent="+Math.max(0,Math.min(100,value)), "");}
}
