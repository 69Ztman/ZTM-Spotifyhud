package de.spotifyhud;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class SpotifyHudClient implements ClientModInitializer {
    private static KeyBinding settingsKey, toggleKey;
    private static final Identifier HUD_ID = Identifier.of("spotifyhud", "spotify_hud");
    private static volatile boolean visible = true;

    @Override public void onInitializeClient() {
        var category = KeyBinding.Category.create(Identifier.of("spotifyhud", "main"));
        // GLFW semicolon is the physical key that produces Ö on a standard German layout.
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.spotifyhud.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_SEMICOLON, category));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.spotifyhud.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.wasPressed()) client.setScreen(new SpotifySettingsScreen());
            while (toggleKey.wasPressed()) visible = !visible;
        });

        HudElementRegistry.addLast(HUD_ID, (drawContext, tickCounter) -> {
            if (visible && MinecraftClient.getInstance().player != null) renderHud(drawContext);
        });
        SpotifyApi.start();
    }

    private static void renderHud(DrawContext ctx) {
        var mc = MinecraftClient.getInstance();
        var cfg = HudConfig.INSTANCE;
        if (!cfg.enabled) return;
        int w = 218, h = 66, margin = 8;
        int x = cfg.position.equals("top-center") ? (mc.getWindow().getScaledWidth() - w) / 2 : (cfg.position.endsWith("right") ? mc.getWindow().getScaledWidth() - w - margin : margin);
        int y = cfg.position.startsWith("bottom") ? mc.getWindow().getScaledHeight() - h - margin : margin;
        int alpha = Math.max(0, Math.min(255, (int)(cfg.opacity * 2.55f)));
        int bg = (alpha << 24) | 0x101018;
        int c1 = cfg.gradient ? SpotifyApi.colorA : 0x30303A;
        int c2 = cfg.gradient ? SpotifyApi.colorB : 0x30303A;
        ctx.fill(x, y, x+w, y+h, bg);
        if (cfg.gradient) {
            for (int i=0;i<w;i++) {
                float t = i/(float)w;
                int r=(int)(((c1>>16)&255)*(1-t)+((c2>>16)&255)*t);
                int g=(int)(((c1>>8)&255)*(1-t)+((c2>>8)&255)*t);
                int b=(int)((c1&255)*(1-t)+(c2&255)*t);
                ctx.fill(x+i,y,x+i+1,y+3,0xFF000000|(r<<16)|(g<<8)|b);
            }
        }
        ctx.drawText(mc.textRenderer, Text.literal("♫  Spotify"), x+8, y+7, 0xFF55DD88, true);
        ctx.drawText(mc.textRenderer, Text.literal(SpotifyApi.title), x+8, y+23, 0xFFFFFFFF, true);
        ctx.drawText(mc.textRenderer, Text.literal(SpotifyApi.artist), x+8, y+38, 0xFFCCCCCC, true);
        ctx.drawText(mc.textRenderer, Text.literal("Ö: Einstellungen  •  H: HUD"), x+8, y+52, 0xFFAAAAAA, false);
    }

    public static void setVisible(boolean value) { visible = value; }
}
