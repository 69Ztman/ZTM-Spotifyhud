package de.spotifyhud;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class SpotifySettingsScreen extends Screen {
    private final Screen parent;
    private int left, top;
    public SpotifySettingsScreen() { this(null); }
    public SpotifySettingsScreen(Screen parent) { super(Text.literal("Spotify HUD Einstellungen")); this.parent = parent; }

    @Override protected void init() {
        left = width/2 - 130; top = height/2 - 118;
        var c = HudConfig.INSTANCE;
        addDrawableChild(ButtonWidget.builder(Text.literal("Position: " + c.position), b -> {
            String[] p={"top-right","bottom-right","top-left","bottom-left","top-center"};
            int i=0; for(int n=0;n<p.length;n++) if(p[n].equals(c.position)) i=n;
            c.position=p[(i+1)%p.length]; b.setMessage(Text.literal("Position: "+c.position)); c.save();
        }).dimensions(left, top+24, 260, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("HUD-Design: " + designName(c.position)), b -> {
            c.position = c.position.equals("top-center") ? "top-right" : "top-center";
            b.setMessage(Text.literal("HUD-Design: " + designName(c.position))); c.save();
        }).dimensions(left, top+51, 260, 20).build());
        addDrawableChild(new SliderWidget(left, top+78, 260, 20, Text.literal("Hintergrund-Transparenz: "+c.opacity+"%"), c.opacity/100.0) {
            @Override protected void updateMessage() { setMessage(Text.literal("Hintergrund-Transparenz: "+(int)(value*100)+"%")); }
            @Override protected void applyValue() { c.opacity=(int)(value*100); c.save(); }
        });
        addDrawableChild(ButtonWidget.builder(Text.literal("Farbverlauf: "+(c.gradient?"An":"Aus")), b -> {
            c.gradient=!c.gradient; b.setMessage(Text.literal("Farbverlauf: "+(c.gradient?"An":"Aus"))); c.save();
        }).dimensions(left, top+105, 260, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Farbverlauf animieren: "+(c.animatedGradient?"An":"Aus")), b -> {
            c.animatedGradient=!c.animatedGradient; b.setMessage(Text.literal("Farbverlauf animieren: "+(c.animatedGradient?"An":"Aus"))); c.save();
        }).dimensions(left, top+132, 260, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Albumcover anzeigen: "+(c.showCover?"An":"Aus")), b -> {
            c.showCover=!c.showCover; b.setMessage(Text.literal("Albumcover anzeigen: "+(c.showCover?"An":"Aus"))); c.save();
        }).dimensions(left, top+159, 260, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Lyrics anzeigen: "+(c.showLyrics?"An":"Aus")), b -> {
            c.showLyrics=!c.showLyrics; b.setMessage(Text.literal("Lyrics anzeigen: "+(c.showLyrics?"An":"Aus"))); c.save();
        }).dimensions(left, top+186, 260, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Schließen"), b -> close()).dimensions(left, top+213, 260, 20).build());
    }
    private static String designName(String position) {
        return position.equals("top-center") ? "Oben mittig" : "Oben rechts";
    }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width/2, top+5, 0xFFFFFFFF);
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Spotify HUD v0.3.0 by ZTM"),
                width/2, top+238, 0xFFB8B8B8);
    }
    @Override public void close() { if (client != null) client.setScreen(parent); }
}
